import React, { useEffect, useState } from "react";
import UserMenu from "./UserMenu";
import { useAuth } from "../../../AuthContext";
import { motion, AnimatePresence } from "framer-motion";
import RentalNavbar from "../RentalNavBar";
import ListingCard from "../../ui/ListingCard";
import Nodata from "../../ui/Nodata";
import DashBoardTab from "../../ui/DashBoardTab";
import { getMyListingProperty } from "../../services/NewApi"; // <-- your API

function ManageListing() {
  const { user } = useAuth();

  const menuItems = ["All", "Listed", "Unlisted"];
  const [manageList, setManageList] = useState(() => {
    return localStorage.getItem("manageListmenu") || "All";
  });

  const [listed, setListed] = useState([]);
  const [unlisted, setUnlisted] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Persist menu selection
  useEffect(() => {
    localStorage.setItem("manageListmenu", manageList);
  }, [manageList]);

  // Fetch data for both Listed and Unlisted on mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError("");

        const [listedRes, unlistedRes] = await Promise.all([
          getMyListingProperty({ status: "Listed" }),
          getMyListingProperty({ status: "Unlisted" }),
        ]);

        setListed(listedRes?.properties?.data || []);
        setUnlisted(unlistedRes?.properties?.data || []);
      } catch (err) {
        setError(err?.message || "Failed to load properties");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleMenuItem = (item) => setManageList(item);

  const tripTypes = { Listed: listed, Unlisted: unlisted };

  return (
    <>
      <RentalNavbar />
      <UserMenu />
      <section className="bg-gray-50 min-h-screen">
        <div className="py-10 mx-auto w-xs sm:w-2xl md:w-3xl xl:w-7xl">
          <div className="flex flex-col md:flex-row gap-6">
            <aside className="md:w-1/4 w-full">
              <DashBoardTab
                menuItems={menuItems}
                menu={manageList}
                handleMenuItem={handleMenuItem}
              />
            </aside>

            <main className="flex-1 space-y-4">
              {loading && (
                <p className="text-gray-600 text-center py-10">Loading...</p>
              )}
              {error && (
                <p className="text-red-500 text-center py-10">{error}</p>
              )}

              <AnimatePresence>
                {!loading && !error && (
                  <>
                    {manageList === "All"
                      ? menuItems
                        .filter((item) => item !== "All")
                        .map((item) => {
                          const list = tripTypes[item];
                          return (
                            <motion.div
                              key={item}
                              initial={{ opacity: 0, x: 20 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: -20 }}
                              transition={{ duration: 0.3 }}
                            >
                              {list.length === 0 ? (
                                <Nodata />
                              ) : (
                                <ListingCard items={list} />
                              )}
                            </motion.div>
                          );
                        })
                      : (() => {
                        const list = tripTypes[manageList];
                        return (
                          <motion.div
                            key={manageList}
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                            transition={{ duration: 0.3 }}
                          >
                            {list.length === 0 ? (
                              <Nodata />
                            ) : (
                              <ListingCard items={list} />
                            )}
                          </motion.div>
                        );
                      })()}
                  </>
                )}
              </AnimatePresence>
            </main>
          </div>
        </div>
      </section>
    </>
  );
}

export default ManageListing;
