import React from 'react'

function AddCity() {
  return (
    <div>AddCity</div>
  )
}

export default AddCity