import React from 'react'
import RentalNavbar from '../components/RentalNavbar';

function AboutUs() {
  return (
    <>
     <RentalNavbar />
     <h1>About us</h1>
    </>
  )
}

export default AboutUs